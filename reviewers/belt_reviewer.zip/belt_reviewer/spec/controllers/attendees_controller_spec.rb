require 'rails_helper'

RSpec.describe AttendeesController, type: :controller do

end
