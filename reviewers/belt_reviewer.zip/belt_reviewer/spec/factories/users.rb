FactoryBot.define do
  factory :user do
    first_name "MyString"
    last_name "MyString"
    email "MyString"
    city "MyString"
    state "MyString"
    password ""
  end
end
