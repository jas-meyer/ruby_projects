FactoryBot.define do
  factory :event do
    name "MyString"
    date "2018-04-17"
    city "MyString"
    state "MyString"
    comment "MyText"
    user nil
  end
end
