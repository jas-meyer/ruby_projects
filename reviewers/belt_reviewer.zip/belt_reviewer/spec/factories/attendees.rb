FactoryBot.define do
  factory :attendee do
    user nil
    event nil
  end
end
