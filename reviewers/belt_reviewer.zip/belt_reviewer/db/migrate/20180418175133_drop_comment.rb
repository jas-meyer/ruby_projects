class DropComment < ActiveRecord::Migration
  def change
  end
end
