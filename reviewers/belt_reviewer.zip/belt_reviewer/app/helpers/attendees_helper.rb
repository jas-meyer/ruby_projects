module AttendeesHelper
end
