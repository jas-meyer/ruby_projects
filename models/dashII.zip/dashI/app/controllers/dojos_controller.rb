class DojosController < ApplicationController
	def index
		@dojos = Dojo.all
		@count = @dojos.count
	end
	def new

	end
	def create
		@dojo = Dojo.new(dojo_params)
		valid = @dojo.valid?
		if valid == true
			flash[:success] = "Great Success! WAWA We WA"
			@dojo = Dojo.create(dojo_params)
			redirect_to "/dojos"
		else
			flash[:error]= @dojo.errors.full_messages
			p flash[:error]
			redirect_to "/dojos/new"
		end
	end
	private
		def dojo_params
			params.require(:dojo).permit(:branch, :street, :city, :state)
		end
end
