class Student < ActiveRecord::Base
  belongs_to :dojo
end
