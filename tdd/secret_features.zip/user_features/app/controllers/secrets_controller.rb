class SecretsController < ApplicationController
  def index
  @secrets = Secret.all
  end
  def create
    @secret = Secret.new(secret_params)
  	@secret.save
  	user_id = session[:user_id]
  		redirect_to "/users/#{user_id}"
   end
 def destroy
 	@secret = Secret.find(params[:id])
 	@secret.destroy
 	user_id = session[:user_id]
  		redirect_to "/users/#{user_id}"
   end

private
    def secret_params
      params.require(:secret).permit(:content, :user_id)
    end

end
