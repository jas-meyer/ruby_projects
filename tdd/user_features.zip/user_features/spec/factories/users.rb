FactoryBot.define do
  factory :user do
    name "Oscar Vazquez"
    email "oscar@gmail.com"
    password "password"
  end
end
