class Mammal
	@@health = 150

	def display_health
		puts "Health: #{@@health}"
		self
	end

end